package guiUserUpdate;

public class Model {

}
